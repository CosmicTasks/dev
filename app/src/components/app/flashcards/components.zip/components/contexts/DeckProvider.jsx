import React, { createContext, useState } from 'react';

export const DeckContext = createContext();

const DeckProvider = ({ children }) => {
  const [decks, setDecks] = useState([]);
  const [selectedDeck, setSelectedDeck] = useState(null);
  const [flashcards, setFlashcards] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCreatingDeck, setIsCreatingDeck] = useState(false);
  const [flashcardToEdit, setFlashcardToEdit] = useState(null);

  const selectDeck = (deckId) => {
    const deck = decks.find(d => d.id === deckId);
    setSelectedDeck(deck);
  };

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  const saveFlashcard = (flashcard) => {
    const updatedDecks = decks.map(deck =>
      deck.id === flashcard.deckId
        ? { ...deck, flashcards: [...deck.flashcards, flashcard] }
        : deck
    );
    setDecks(updatedDecks);
  };

  const saveDeck = (deck) => {
    setDecks([...decks, deck]);
  };

  return (
    <DeckContext.Provider value={{
      decks,
      selectedDeck,
      flashcards,
      isModalOpen,
      isCreatingDeck,
      flashcardToEdit,
      selectDeck,
      openModal,
      closeModal,
      saveFlashcard,
      saveDeck,
      setIsCreatingDeck
    }}>
      {children}
    </DeckContext.Provider>
  );
};

export default DeckProvider;